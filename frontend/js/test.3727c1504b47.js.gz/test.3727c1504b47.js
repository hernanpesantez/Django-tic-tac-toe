console.log(3 + 4 + "5")
console.log(3 + 4 + +"5")
console.log(77 == '77')
console.log(77 === '77')

console.log(false == 0)

console.log(false === 0)